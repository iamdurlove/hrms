<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Monthly Invoice</title>
    <style>
        @font-face {
            font-family: 'Figtree';
        }
        body {
            font-family: 'Figtree', sans-serif;
        }
    </style>
</head>

<body>
<h1>Request Status Update</h1>

<p>Hello <?php echo e($request->employee->name); ?>,</p>

<p>This mail is regarding your request #<?php echo e($request->id); ?> submitted on <?php echo e(\Carbon\Carbon::createFromTimeString($request->created_at)->toDateString()); ?></p><br />
<hr><br />
<h3>Your Request status has been updated to <b style="color: <?php echo e($request->status == 'Rejected' ? 'red' : 'green'); ?>"><?php echo e($request->status); ?></b>.</h3>
<?php if($request->status == 'Rejected' && $request->admin_response): ?>
    <p>Rejection Reason: <?php echo e($request->admin_response); ?>.</p>
<?php endif; ?>

<br />
<hr>
<br />

<p>If you have any questions or concerns, please feel free to submit a complaint request from your account.</p>

<p><br /><b>Thank you!</b></p>
</body>
</html>
<?php /**PATH C:\Users\HP\Desktop\final project\hrms\resources\views/emails/request-update.blade.php ENDPATH**/ ?>