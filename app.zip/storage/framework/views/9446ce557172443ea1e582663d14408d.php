<script>
    window._translations = <?php echo json_encode($translations, 15, 512) ?>;
</script>
<?php /**PATH C:\Users\HP\Desktop\final project\hrms\resources\views/components/translations.blade.php ENDPATH**/ ?>