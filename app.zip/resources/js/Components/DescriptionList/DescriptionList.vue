<script setup>

</script>

<template>

    <div class="overflow-hidden sm:rounded-lg py-4">
        <dl>
            <div  class="grid grid-cols-2">
                <slot />
            </div>
        </dl>
    </div>
</template>
