<template>
    <dt class="text-sm font-medium text-gray-500">
        <slot />
    </dt>
</template>
