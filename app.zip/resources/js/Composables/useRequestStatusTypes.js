import {__} from "@/Composables/useTranslations.js";

export const request_status_types = {
    pending: __('Pending'),
    approved: __('Approved'),
    rejected: __('Rejected'),
}
